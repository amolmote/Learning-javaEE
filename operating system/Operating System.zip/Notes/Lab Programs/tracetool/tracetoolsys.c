#include<stdio.h>

int main(int argc, char const *argv[])
{
    write(1, "Hello", 5);
    write(1, "World", 5);
    return 0;
}
