#include<stdio.h>

int main(int argc, char const *argv[])
{
    printf("Hello \n");
    printf("World \n");
    return 0;
}
