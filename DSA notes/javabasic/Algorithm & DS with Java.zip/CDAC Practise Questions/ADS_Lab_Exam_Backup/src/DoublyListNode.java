
public class DoublyListNode {
	DoublyListNode prev;
	DoublyListNode next;
	int val;
	
	public DoublyListNode(int data) {
		this.val = data;
		prev = null;
		next = null;
	}
}
