package com.app.core;

public enum Category {
	NOVEL,HORROR,EDUCATIONAL,MYSTERY,ROMANCE,FANTASY;
}
