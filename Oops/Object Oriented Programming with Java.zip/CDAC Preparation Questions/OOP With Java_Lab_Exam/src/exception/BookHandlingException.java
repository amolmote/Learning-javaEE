package exception;

@SuppressWarnings("serial")
public class BookHandlingException extends Exception {
	public BookHandlingException(String msg) {
		super(msg);
	}
}
